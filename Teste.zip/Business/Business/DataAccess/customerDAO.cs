﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Objects;
using DatabaseFactory;
using System.Data;
using Util;


namespace Business.DataAccess
{
        
    public class CustomerDAO
    {
        public CustomerDAO()
        {
        }

        public DataTable GetCustomer(int pIdUser, string pName, int pIdGender, int pIdCity, int pIdRegion, DateTime pLastPurchase1, DateTime pLastPurchase2, int pIdClassification, int pIdSeller)
        {
            string sql = "";
            SqlDB db = new SqlDB();
            DateTime dateAux = new DateTime();

            sql += "select Customer.*, Gender.Name GenderName, City.Name CityName, Region.Name RegionName, Classification.Name ClassificationName " + Environment.NewLine;
            sql += "from Customer " + Environment.NewLine;
            sql += "inner join Gender on Customer.GenderId = Gender.Id " + Environment.NewLine;
            sql += "inner join City on Customer.CityId = City.Id " + Environment.NewLine;
            sql += "inner join Region on Customer.RegionId = Region.Id " + Environment.NewLine;
            sql += "inner join Classification on Customer.ClassificationId = Classification.Id " + Environment.NewLine;
            sql += "where (1=1) " + Environment.NewLine;

            if (pIdUser != 0)
                sql += "and UserId = " + pIdUser + Environment.NewLine;

            if(pName != "")
                sql += "and Name like '%{pName}%'".Replace("{pName}", pName) + Environment.NewLine;

            if (pIdGender != 0)
                sql += "and GenderId = " + pIdGender + Environment.NewLine;

            if (pIdCity != 0)
                sql += "and CityId = " + pIdCity + Environment.NewLine;

            if (pIdRegion != 0)
                sql += "and RegionId = " + pIdRegion + Environment.NewLine;

            if (pIdClassification != 0)
                sql += "and ClassificationId = " + pIdClassification + Environment.NewLine;

            if (pIdSeller != 0)
                sql += "and SellerId = " + pIdSeller + Environment.NewLine;           

            if (pLastPurchase1 > dateAux)
                sql += "and LastPurchase >= '%{pLastPurchase1}%'".Replace("{pLastPurchase1}", pLastPurchase1.ToString("yyyy-MM-dd")) + Environment.NewLine;
			
            if (pLastPurchase2 > dateAux)
                sql += "and LastPurchase <= '%{pLastPurchase2}%'".Replace("{pLastPurchase2}", pLastPurchase2.ToString("yyyy-MM-dd")) + Environment.NewLine;

            DataTable tableCustomer = db.ExecuteDataTable(sql);

            //List<User> listUsers = Conversor.ToListof<User>(tableUser);

            return tableCustomer;

            /*if (listUsers.Count > 0)
                return listUsers[0];
            else
                return null;*/
        }

    }

}
