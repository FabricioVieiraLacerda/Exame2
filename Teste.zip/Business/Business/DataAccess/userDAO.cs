﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Objects;
using DatabaseFactory;
using System.Data;
using Util;

namespace Business.DataAccess
{
        
    public class userDAO
    {
        public userDAO()
        {
        }

        public User GetUser(string pEmail)
        {
            string sql = "";
            SqlDB db = new SqlDB();

            sql += "select UserSys.*, UserRole.IsAdmin " + Environment.NewLine;
            sql += "from UserSys " + Environment.NewLine;
            sql += "inner join UserRole on UserSys.UserRoleId =  UserRole.Id " + Environment.NewLine;
            sql += "where Email = '{0}' " + Environment.NewLine;

            DataTable tableUser = db.ExecuteDataTable(String.Format(sql, pEmail));

            List<User> listUsers = Conversor.ToListof<User>(tableUser);

            if (listUsers.Count > 0)
                return listUsers[0];
            else
                return null;
        }

    }

}
