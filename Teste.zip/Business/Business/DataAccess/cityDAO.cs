﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Objects;
using DatabaseFactory;
using System.Data;
using Util;

namespace Business.DataAccess
{
        
    public class CityDAO
    {
        public CityDAO()
        {
        }

        public DataTable GetCity(int pIdRegion)
        {
            string sql = "";
            SqlDB db = new SqlDB();

            sql += "select * from City inner join Region on Customer.RegionId = Region.Id ";

            if(pIdRegion > 0)
                sql += " where Customer.RegionId = " + pIdRegion;

            DataTable tableCity = db.ExecuteDataTable(sql);            

            return tableCity;

        }

    }

}
