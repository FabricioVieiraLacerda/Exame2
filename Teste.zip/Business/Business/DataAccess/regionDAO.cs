﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Objects;
using DatabaseFactory;
using System.Data;
using Util;

namespace Business.DataAccess
{
        
    public class RegionDAO
    {
        public RegionDAO()
        {
        }

        public DataTable GetRegion()
        {
            SqlDB db = new SqlDB();
            DataTable tableRegion = db.ExecuteDataTable(String.Format("select * from Region"));

            //List<User> listUsers = Conversor.ToListof<User>(tableUser);

            return tableRegion;

            /*if (listUsers.Count > 0)
                return listUsers[0];
            else
                return null;*/
        }

    }

}
