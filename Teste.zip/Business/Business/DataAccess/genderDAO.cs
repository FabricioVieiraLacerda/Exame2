﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Objects;
using DatabaseFactory;
using System.Data;
using Util;

namespace Business.DataAccess
{
        
    public class GenderDAO
    {
        public GenderDAO()
        {
        }

        public DataTable GetGender()
        {
            SqlDB db = new SqlDB();
            DataTable tableGender = db.ExecuteDataTable(String.Format("select * from Gender"));

            //List<User> listUsers = Conversor.ToListof<User>(tableUser);

            return tableGender;

            /*if (listUsers.Count > 0)
                return listUsers[0];
            else
                return null;*/
        }

    }

}
