﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Objects;
using DatabaseFactory;
using System.Data;
using Util;

namespace Business.DataAccess
{
        
    public class ClassificationDAO
    {
        public ClassificationDAO()
        {
        }

        public DataTable GetClassification()
        {
            SqlDB db = new SqlDB();
            DataTable tableClassification = db.ExecuteDataTable(String.Format("select * from Classification"));

            //List<User> listUsers = Conversor.ToListof<User>(tableUser);

            return tableClassification;

            /*if (listUsers.Count > 0)
                return listUsers[0];
            else
                return null;*/
        }

    }

}
