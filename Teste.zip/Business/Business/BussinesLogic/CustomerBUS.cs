﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business.DataAccess;
using System.Data;
using Objects;

namespace Business.BussinesLogic
{
    public class CustomerBUS
    {
        public CustomerBUS() { }

        public DataTable GetCustomer(User pUser, string pName, int pIdGender, int pIdCity, int pIdRegion, DateTime pLastPurchase1, DateTime pLastPurchase2, int pIdClassification, int pIdSeller)
        {

            try
            {
                int idUser=0;
                CustomerDAO customerDAO = new CustomerDAO();

                if (!pUser.IsAdmin)
                    idUser = pUser.Id;

                if (pLastPurchase1 < pLastPurchase2)
                    throw new Exception("A data inicial deve ser menor que a final.");

                return customerDAO.GetCustomer(idUser, pName, pIdGender, pIdCity, pIdRegion, pLastPurchase1, pLastPurchase2, pIdClassification, pIdSeller );

            }
            catch(Exception ex)
            {
                throw ex;
            }

        }


        }

    }
