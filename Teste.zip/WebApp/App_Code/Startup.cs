﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(CursoDesignPatterns.Startup))]
namespace CursoDesignPatterns
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
