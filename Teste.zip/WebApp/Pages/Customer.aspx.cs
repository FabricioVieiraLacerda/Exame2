﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Objects;
using Business.DataAccess;
using Business.BussinesLogic;

public partial class Pages_Customer : System.Web.UI.Page
{
    private User userLogged;

    protected void Page_Load(object sender, EventArgs e)
    {
        userLogged = (User)Session["userLogged"];

        FillDropDowns();
        FillGrid(userLogged, "", 0,0,0, new DateTime(), new DateTime(), 0, 0);

        if (!userLogged.IsAdmin)
        {
            lblSeller.Visible = false;
            cboSeller.Visible = false;
        }
    }

    public void FillDropDowns()
    {
        ClassificationDAO classificationDAO = new ClassificationDAO();
        GenderDAO genderDAO = new GenderDAO();
        RegionDAO regionDAO = new RegionDAO();

        cboRegion.DataSource = regionDAO.GetRegion();
        cboRegion.DataBind();
        cboRegion.Items.Insert(0, new ListItem("<Select>", "0"));

        cboGender.DataSource = genderDAO.GetGender();
        cboGender.DataBind();
        cboGender.Items.Insert(0, new ListItem("<Select>", "0"));

        cboClassification.DataSource = classificationDAO.GetClassification();
        cboClassification.DataBind();
        cboClassification.Items.Insert(0, new ListItem("<Select>", "0"));
        

    }

    public void FillDropDownCity(int pIdRegion){
	        CityDAO cityDAO = new CityDAO();
                        
        cboCity.DataSource = cityDAO.GetCity(0);
        cboCity.DataBind();
        cboCity.Items.Insert(0, new ListItem("<Select>", "0"));
    }

    public void FillGrid(User pUser, string pName, int pIdGender, int pIdCity, int pIdRegion, DateTime pLastPurchase1, DateTime pLastPurchase2, int pIdClassification, int pIdSeller)
    {
        try{ 
            CustomerBUS customerBUS = new CustomerBUS();

            GridView1.DataSource = customerBUS.GetCustomer(pUser, pName, pIdGender, pIdCity, pIdRegion, pLastPurchase1, pLastPurchase2, pIdClassification, pIdSeller);
            GridView1.DataBind();
        }
        catch(Exception ex1)
        {
            lblMsg.Text = ex1.Message;
        }

    }

    protected void cboRegion_SelectedIndexChanged(object sender, EventArgs e)
    {
	    FillDropDownCity(Convert.ToInt32(cboRegion.SelectedValue));
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
	    FillGrid( userLogged, txtName.Text, 
			    Convert.ToInt32(cboGender.SelectedValue),
			    Convert.ToInt32(cboCity.SelectedValue),
			    Convert.ToInt32(cboRegion.SelectedValue),
			    Convert.ToDateTime(txtPurchase1.Text),
			    Convert.ToDateTime(txtPurchase2.Text),
			    Convert.ToInt32(cboClassification.SelectedValue),
			    Convert.ToInt32(cboSeller.SelectedValue)
	        );
    }

}