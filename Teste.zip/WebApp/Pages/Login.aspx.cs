﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Objects;
using Business.DataAccess;
using Util;

public partial class Pages_Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        Boolean isValidUserPass = false;
        userDAO userData = new userDAO();
        User user = userData.GetUser(txtEmail.Text);        

        Session["userLogged"] = user;
                
        if (user != null)
        {
            if ( Encrypt.DecryptString(Encrypt.GlobalcipherText, user.Password) == txtPass.Text)            
                Response.Redirect("~/Pages/Customer.aspx");

        }

        if(!isValidUserPass)
            lblMsg.Text = @"The e-mail and/or password entered is invalid.Please try again.";

    }
}